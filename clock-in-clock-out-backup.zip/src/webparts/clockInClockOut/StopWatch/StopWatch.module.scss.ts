/* tslint:disable */
require("./StopWatch.module.css");
const styles = {
  StopWatch: 'StopWatch_746d48ac',
  Header: 'Header_746d48ac',
  webpartTitle: 'webpartTitle_746d48ac',
  clockIocn: 'clockIocn_746d48ac',
  inOutDetails: 'inOutDetails_746d48ac',
  totalTime: 'totalTime_746d48ac',
  time: 'time_746d48ac',
  clockedInTime: 'clockedInTime_746d48ac',
  data: 'data_746d48ac',
  playButton: 'playButton_746d48ac',
  ClockInButtonText: 'ClockInButtonText_746d48ac',
  records: 'records_746d48ac',
  todayTime: 'todayTime_746d48ac',
  totalTimeText: 'totalTimeText_746d48ac',
  inoutStatus: 'inoutStatus_746d48ac',
  demo: 'demo_746d48ac',
  main: 'main_746d48ac',
  buttonImg: 'buttonImg_746d48ac',
  scrollBar: 'scrollBar_746d48ac',
  line: 'line_746d48ac',
  arrow: 'arrow_746d48ac',
  todayTotalTime: 'todayTotalTime_746d48ac'
};

export default styles;
/* tslint:enable */