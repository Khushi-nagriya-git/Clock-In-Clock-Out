export interface IStopWatchProps {
    spHttpClient: any;
    absoluteURL: any;
    listName:string;
    backgroundColor:string;
  }