/* tslint:disable */
require("./ClockInClockOut.module.css");
const styles = {
  clockInClockOut: 'clockInClockOut_7f8083f1'
};

export default styles;
/* tslint:enable */