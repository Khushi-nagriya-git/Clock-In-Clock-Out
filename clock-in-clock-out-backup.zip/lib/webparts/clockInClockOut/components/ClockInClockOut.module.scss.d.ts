declare const styles: {
    clockInClockOut: string;
};
export default styles;
//# sourceMappingURL=ClockInClockOut.module.scss.d.ts.map