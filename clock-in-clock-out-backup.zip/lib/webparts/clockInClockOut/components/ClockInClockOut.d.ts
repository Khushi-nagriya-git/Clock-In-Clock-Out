import * as React from 'react';
import type { IClockInClockOutProps } from './IClockInClockOutProps';
declare const ClockInClockOut: React.FunctionComponent<IClockInClockOutProps>;
export default ClockInClockOut;
//# sourceMappingURL=ClockInClockOut.d.ts.map