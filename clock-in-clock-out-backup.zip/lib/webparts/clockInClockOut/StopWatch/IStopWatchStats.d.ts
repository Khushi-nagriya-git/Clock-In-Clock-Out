export interface InOutDetail {
    start: number;
    end: number;
    total: number;
    status: string;
}
export interface DetailRecord {
    currentDate: {
        username: string;
        employeeId: number;
        status: string;
        todayTotalTime: number;
        firstIn: string;
        lastOut: string;
        inOutDetails: InOutDetail[];
    };
}
export interface CurrentUserDetails {
    Title: string;
    Id: any;
    email: string;
}
export interface UserData {
    EmployeeID: number;
    EmployeeName: string;
    Date: string;
    Status: string;
    TodayTotalTime: number;
    TodayFirstIn: string;
    TodayLastOut: string;
    DetailRecords: DetailRecord[];
}
export declare const initialCurrentUserDetails: CurrentUserDetails;
export declare const initialUserData: UserData;
export declare const initialState: {
    timer: number;
    checkInTime: string;
    isRunning: boolean;
    time: number;
    status: string;
    todayLoggedRecords: any[];
    currentUserDetails: CurrentUserDetails;
    userData: UserData;
};
//# sourceMappingURL=IStopWatchStats.d.ts.map