declare const styles: {
    StopWatch: string;
    Header: string;
    webpartTitle: string;
    clockIocn: string;
    inOutDetails: string;
    totalTime: string;
    time: string;
    clockedInTime: string;
    data: string;
    playButton: string;
    ClockInButtonText: string;
    records: string;
    todayTime: string;
    totalTimeText: string;
    inoutStatus: string;
    demo: string;
    main: string;
    buttonImg: string;
    scrollBar: string;
    line: string;
    arrow: string;
    todayTotalTime: string;
};
export default styles;
//# sourceMappingURL=StopWatch.module.scss.d.ts.map