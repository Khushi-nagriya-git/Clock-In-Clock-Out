import * as React from "react";
import type { IStopWatchProps } from "./IStopWatchProps";
declare const StopWatch: React.FunctionComponent<IStopWatchProps>;
export default StopWatch;
//# sourceMappingURL=StopWatch.d.ts.map