/// <reference types="react" />
export declare const useStopwatch: () => {
    timer: number;
    checInTime: string;
    isRunning: boolean;
    status: string;
    setTimer: import("react").Dispatch<import("react").SetStateAction<number>>;
    setStartTime: import("react").Dispatch<import("react").SetStateAction<string>>;
    setIsRunning: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    setStatus: import("react").Dispatch<import("react").SetStateAction<string>>;
};
//# sourceMappingURL=IStopWatchStates.d.ts.map