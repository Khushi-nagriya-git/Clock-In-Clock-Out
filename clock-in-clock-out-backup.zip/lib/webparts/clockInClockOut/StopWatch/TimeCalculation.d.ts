export declare function totalTime(time: number): string;
export declare function formatTime(timeInSeconds: number): string;
export declare function formatTimeFromTimestamp(timestamp: number): string;
export declare function calculateIntervalTime(todayData: any): number;
//# sourceMappingURL=TimeCalculation.d.ts.map