import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IClockInClockOutWebPartProps {
    description: string;
    absoluteURL: any;
    spHttpClient: any;
    context: any;
    listName: string;
    backgroundColor: string;
}
export default class ClockInClockOutWebPart extends BaseClientSideWebPart<IClockInClockOutWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected get disableReactivePropertyChanges(): boolean;
    protected onAfterPropertyPaneChangesApplied(): void;
    private validateListName;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=ClockInClockOutWebPart.d.ts.map