/// <reference types="react" />
import { SPHttpClient } from "@microsoft/sp-http";
export declare const useUserData: (props: {
    spHttpClient: SPHttpClient;
    absoluteURL: string;
    listName: string;
}) => {
    currentUserDetails: any;
    userData: any;
    todayDetailRecords: any;
    time: number;
    status: string;
    setStatus: import("react").Dispatch<import("react").SetStateAction<string>>;
    setTime: import("react").Dispatch<import("react").SetStateAction<number>>;
    setTodayDetailRecords: import("react").Dispatch<any>;
    setUserData: import("react").Dispatch<any>;
};
//# sourceMappingURL=IservicesStates.d.ts.map